self.addEventListener('Install', function(event) {
    console.log('[SW] Installing Service Worker and Pre-caching app shell...', event);
});