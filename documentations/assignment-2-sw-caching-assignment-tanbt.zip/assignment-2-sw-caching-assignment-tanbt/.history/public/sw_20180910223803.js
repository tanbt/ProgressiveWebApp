var CACHE_STATIC_NAME = 'app-shell';

self.addEventListener('install', function(event) {
    event.waitUntil(
      caches.open(CACHE_STATIC_NAME).then(function(cache) {
        return cache.addAll(
          [
            '/css/bootstrap.css',
            '/css/main.css',
            '/js/bootstrap.min.js',
            '/js/jquery.min.js',
            '/offline.html'
          ]
        );
      })
    );
  });