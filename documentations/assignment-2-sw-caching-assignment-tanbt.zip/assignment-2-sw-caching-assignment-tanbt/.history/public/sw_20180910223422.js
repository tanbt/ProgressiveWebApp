var CACHE_STATIC_NAME = 'app-shell';

self.addEventListener('Install', function(event) {
    console.log('[SW] Installing Service Worker and Pre-caching app shell...', event);

    event.waitUntil(
        caches.open(CACHE_STATIC_NAME).then(function(cache) {
            cache.addAll([
                '/',
                '/index.html',
                '/css/app.css',
                '/css/dynamic.css',
                '/css/main.css',
                '/index.html',
            ]);
        })
    );
});