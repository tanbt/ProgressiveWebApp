self.addEventListener('Install', function(event) {
    
});