var CACHE_STATIC_NAME = 'app-shell';

self.addEventListener('install', function(event) {
    console.log('[SW] Installing Service Worker and Pre-caching app shell...', event);

    event.waitUntil(
        caches.open(CACHE_STATIC_NAME).then(function(cache) {
            cache.addAll([
                '/',
                '/index.html',
                '/src/css/app.css',
                '/src/css/dynamic.css',
                '/src/css/main.css',
                '/src/js/main.js',
                '/src/js/material.min.js',
            ]);
        })
    );
});