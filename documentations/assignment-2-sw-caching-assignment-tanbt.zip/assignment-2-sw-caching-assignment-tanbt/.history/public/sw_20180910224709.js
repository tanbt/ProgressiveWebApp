var CACHE_STATIC_NAME = 'app-shell';

// https://developers.google.com/web/ilt/pwa/caching-files-with-service-worker#storing_resources
self.addEventListener('install', function(event) {
    console.log('[SW] Installing Service Worker and Pre-caching app shell...', event);

    event.waitUntil(
        caches.open(CACHE_STATIC_NAME).then(function(cache) {
            cache.addAll([
                '/',
                '/index.html',
                '/src/css/app.css',
                '/src/css/dynamic.css',
                '/src/css/main.css',
                '/src/js/main.js',
                '/src/js/material.min.js',
            ]);
        })
    );
});

// https://developers.google.com/web/ilt/pwa/caching-files-with-service-worker#serving_files_from_the_cache
self.addEventListener('fetch', function(event) {
    event.respondWith(
      caches.match(event.request).then(function(response) {
        return response ||
        fetch(event.request).then(function (onlineResponse) {
            
        });
      })
    );
  });